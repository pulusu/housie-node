exports.vizagKairosCCgroup = {
  ccArr : ['pennaqqm@kairostech.com','pankqqaj@kairostech.com','swaroqqop@kairostech.com']
}

exports.bccGroup= {
  bccArr: 'swdaroop@kairostech.com'
}

exports.fromAdd="Kairos Housie <housieworld@gmail.com>";
